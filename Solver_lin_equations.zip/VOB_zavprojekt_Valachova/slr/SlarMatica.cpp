#include "stdafx.h"
#include "SlarMatica.h"

//zakladna trieda pre metody GEM a GSM, obsahuje spolocne funkcie atd
SlarMatica::SlarMatica(const vector<vector<double>> &m) //konstruktor
{
	matica = m; 

	chyba_matice = !NastavMaticu(); 
}


SlarMatica::~SlarMatica() //destruktor
{
}



bool SlarMatica::NastavMaticu()
{
	rozmer = (int) matica.size(); //nastavime velkost matice pre neskorsie pouzitie

	vysledok.resize(rozmer); //nastavime velkost matice vysledok na rovnaku velkost ako ma vstupna matica 
	
	//chceme aby matica mala velkost NxN+1, kde posledny stlpec je prava strana
	if (rozmer == matica[0].size() - 1) //kontrolujeme, ci vstupna matica ma v sebe pravu stranu
		return true;
	else
		return false;
}


bool SlarMatica::Pocitaj()
{
	return false;
}


bool SlarMatica::ZapisVysledky(char* filename) //zapis vysledkov do suboru
{
	bool ret = false;
	FILE* vysledky_subor;
	if (fopen_s(&vysledky_subor, filename, "w") != 0) { //otvorime subor, skontrolujeme ci nedoslo k chybe
		perror("Chyba pri zapise vysledkov do suboru \n");
	}
	else
	{
		fprintf(vysledky_subor, "Vysledky\n"); //nadpis v subore
		for (int i = 0; i < vysledok.size(); i++) {
			fprintf(vysledky_subor, "%f\n", vysledok[i]); //zapis jednotlivych hodnot do suboru
		}
		cout << "\n";
		ret = true;
	}
	fclose(vysledky_subor); //zavreme subor

	return ret;
}

void SlarMatica::PorovnajVysledky(const vector<double>& v) //vypise na obrazovku rozdiel medzi vypocitanymi hodnotami a referencnymi vysledkami
{
	cout << "Rozdiel so spravnymi vysledkami je:\n";

	for (int i = 0; i < vysledok.size() || i< v.size(); i++)
    {
		cout << vysledok[i] - v[i] << "\n";
    }

}
