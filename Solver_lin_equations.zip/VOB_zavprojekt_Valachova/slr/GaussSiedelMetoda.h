#pragma once

#include "SlarMatica.h"


class GaussSiedelMetoda : public SlarMatica
{
private:
	int pocetIteracii;

public:
	GaussSiedelMetoda(const vector<vector<double>> &m, int p);
	~GaussSiedelMetoda();

	bool Pocitaj();
};

