#pragma once

#include <vector>

using namespace std;

enum eCoCitaj{

	CITAJ_DATA,
	CITAJ_STLPCE,
	CITAJ_RIADKY,
	CITAJ_KUMULOVANE_RIADKY,
	CITAJ_RHS,
	CITAJ_VYSEDKY
};

class CitacRiedkejMatice
{
private:
	vector<double> hodnoty;
	vector<uint32_t> stlpce;
	vector<uint32_t> riadky;
	vector<uint32_t> kumul_riadky;

	vector<double> prava_strana;

	

	eCoCitaj coCitaj;

	bool Spracuj(char* riadok);

	bool VytvorMaticu();


public:
	
	vector<vector<double>> matica;
	vector<double> vysledky;

	bool Citaj();


	CitacRiedkejMatice();
	~CitacRiedkejMatice();
};

