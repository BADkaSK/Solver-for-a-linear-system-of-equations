#include "stdafx.h"
//#include "CitacRiedkejMatice.h"

#define DLZKA_RIADKU 64

CitacRiedkejMatice::CitacRiedkejMatice() //konstruktor
{
}


CitacRiedkejMatice::~CitacRiedkejMatice() //destruktor
{
}

bool CitacRiedkejMatice::Citaj()
{
	FILE * subor; 
	char riadok[DLZKA_RIADKU]; //predpokladame dlzku riadku nie vacsiu ako 64 bytov

	bool navrat = true;

	// Citanie datoveho suboru
	if (fopen_s(&subor, "..\\data\\MATRIX.DAT", "r") != 0) {
		perror("Chyba citania datoveho suboru\n");
		navrat = false;
	}
	else {
		//najskor citame nadpis, ktory rozdeluje data na skupiny 
		while (fgets(riadok, DLZKA_RIADKU, subor) != NULL) {
			if (strstr(riadok, "array")) //ked je nadpis array, su to hodnoty v matici
				coCitaj = CITAJ_DATA;
			else if (strstr(riadok, "column_index"))
				coCitaj = CITAJ_STLPCE; //indexy hodnot v stlpcoch
			else if (strstr(riadok, "accumulated_row_size"))
				coCitaj = CITAJ_KUMULOVANE_RIADKY; //indexy kumulovanych riadkov
			else if (strstr(riadok, "row_size"))
				coCitaj = CITAJ_RIADKY; //rozmer riadku, nebol potrebny na identifikaciu dat
			else
				Spracuj(riadok); //data sa zapisu do pola podla predosleho rozdelenia

			cout << riadok; //vypis na obrazovku
		}
		fclose(subor);
	}

	// Citanie pravej strany
	if (fopen_s(&subor, "..\\data\\RHS.DAT", "r") != 0) {
		perror("Chyba citania suboru dat prvej strany\n");
		navrat = false;
	}
	else {
		coCitaj = CITAJ_RHS; //nastavime hodnotu pre funkciu Spracuj
		while (fgets(riadok, DLZKA_RIADKU, subor) != NULL) {
			Spracuj(riadok);
			cout << riadok; //vypis na obrazovku
		}
		fclose(subor);
	}

	// Citanie vysledkov
	if (fopen_s(&subor, "..\\data\\SOLUTION.DAT", "r") != 0) {
		perror("Chyba citania suboru vysledkov\n");
	}
	else {
		coCitaj = CITAJ_VYSEDKY; //nastavime hodnotu pre funkciu Spracuj
		while (fgets(riadok, DLZKA_RIADKU, subor) != NULL) {
			Spracuj(riadok); //zapise udaje zo suboru do pola
			cout << riadok; //vypis na obrazovku
		}
		fclose(subor);
	}

	VytvorMaticu(); //vytvori sa matica z predosle zistenych udajov, velkosti NxN+1

	return navrat;
}


bool CitacRiedkejMatice::Spracuj(char* riadok)
{
	//podla typu dat ukladame do jednotlivych poli
	switch (coCitaj) {
	case CITAJ_DATA:
		hodnoty.push_back(atof(riadok));
		break;
	case CITAJ_STLPCE:
		stlpce.push_back(atoi(riadok));
		break;
	case CITAJ_RIADKY:
		riadky.push_back(atoi(riadok));
		break;
	case CITAJ_KUMULOVANE_RIADKY:
		kumul_riadky.push_back(atoi(riadok));
		break;
	case CITAJ_RHS:
		prava_strana.push_back(atof(riadok));
		break;
	case CITAJ_VYSEDKY:
		vysledky.push_back(atof(riadok));
		break;
	}
	return true;
}


bool CitacRiedkejMatice::VytvorMaticu() //vytvori vyslednu maticu aj s vektorom pravej strany
{
	uint32_t pocet_prvkov  = 0;

	size_t size = vysledky.size();

	matica.resize(size); //velkost matice nastavime podla velkosti pola vysledkov, predpokladame ze matice su konzistentne
	for (auto &it : matica) //kazdemu riadku nastavi pozadovany pocet stlpcov
		it.resize(size); 
	
	unsigned int j =0;

	for (unsigned int i = 0; i < hodnoty.size(); i++)
	{
		//vlozime hodnoty do matice sustavy
		matica[j][stlpce[i]] = hodnoty[i];
		
		pocet_prvkov++; //inkrementujeme pocet prvkov, aby sme vedeli podla hodnoty kumulativnych riadkov kedy prejst na dalsi riadok
		 
		if (j + 1 < kumul_riadky.size()) { //kontrola, aby sme nepresiahli cez velkost vektora kumulativnych riadov (j+1 by mohlo byt vacsie ako rozmer)
			if (kumul_riadky[j + 1] <= pocet_prvkov) { //zistujeme ci pocet prvkov dosiahol hodnotu vo vektore kumulativnych riadkov  
				j++; //ak ano tak prechadzame na dalsi riadok
			}
		}
	}
	// pripojenie pravej strany do matice
	for (unsigned int i = 0; i < vysledky.size(); i++) {
		matica[i].push_back(prava_strana[i]);
	}
	return true;
}




