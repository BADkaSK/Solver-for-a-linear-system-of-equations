#include "stdafx.h"
#include <time.h> 
#include <windows.h>

GaussElimincnaMetoda::GaussElimincnaMetoda(const vector<vector<double>> &m) : SlarMatica(m) //konstruktor
{
	NastavMaticu();
}


GaussElimincnaMetoda::~GaussElimincnaMetoda() //destruktor
{ 

}


bool GaussElimincnaMetoda::Pocitaj()
{
	int i, j, k;

	ULONGLONG mtime = GetTickCount64(); //spocita potrebny cas na vypocet v ms

	vector<double>  tmpRow; 
	if (!chyba_matice) {
		for (i = 0; i < rozmer; i++)
		{
			for (j = i + 1; j < rozmer; j++)
			{
				if (abs(matica[i][i]) < abs(matica[j][i])) //zistujeme ci prvok na diagonale je mensi ako prvok v stlpci pod nim
				{
					//ak je, potom prehodime riadky, aby na diagonale bolo vzdy najvacsie cislo v stlpci v abs.h
					tmpRow = matica[i]; //prvok ulozime do pom premennej aby sa nestratila hodnota
					matica[i] = matica[j]; //riadky prehodime
					matica[j] = tmpRow; //do j-teho riadku vratime hodnotu co bola na i-tom
				}
			}
		}
		//uprav�me maticu na hornu trojuholnikovu
		for (i = 0; i < rozmer - 1; i++)
		{
			for (j = i + 1; j < rozmer; j++)
			{
				double f = matica[j][i] / matica[i][i]; //deklaracia nasobku ktory budeme odpocitavat
				for (k = 0; k < rozmer + 1; k++)
				{
					matica[j][k] = matica[j][k] - f * matica[i][k]; //odratame f-nasobok predchadzajuceho riadku od aktualneho, aby sme dostali 0 na k-tom stlpci
				}
			}
		}
		for (i = rozmer - 1; i >= 0; i--) //zaciname od posledneho riadku
		{
			vysledok[i] = matica[i][rozmer];

			for (j = i + 1; j < rozmer; j++)
			{
				if (i != j)
				{
					vysledok[i] = vysledok[i] - matica[i][j] * vysledok[j]; //postupna uprava matic
				}
			}
			vysledok[i] = vysledok[i] / matica[i][i]; //nakoniec podel�me koeficientom pred premennou 
		}
		cout << "\nCas vypoctu Gaussovej eliminacnej metody: " << GetTickCount64() - mtime << " milisekund"; //vypiseme cas, za ktory prebehne vypocet

		cout << "\nVysledky su zapisane v subore GEM.txt:\n"; //vypis vysledkov na obrazovku
		cout << "\nVypis:\n";
		for (i = 0; i < rozmer; i++) {
			cout << "x" << i + 1 << "=" << vysledok[i] << "\n"; //obrazovka
		}
		const char filename[] = "..\\data\\GEM.txt";
		ZapisVysledky((char*)filename);

		return true;
	}
	else
		return false;

}