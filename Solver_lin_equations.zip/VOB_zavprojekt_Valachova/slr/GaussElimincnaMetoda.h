#pragma once

#include "SlarMatica.h"


class GaussElimincnaMetoda : public SlarMatica //odvodene zo zakladnej triedy
{

public:
	GaussElimincnaMetoda(const vector<vector<double>> &m);
	~GaussElimincnaMetoda();

	bool Pocitaj();
};

