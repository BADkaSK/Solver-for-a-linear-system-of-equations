#include "stdafx.h"
#include <windows.h>


GaussSiedelMetoda::GaussSiedelMetoda(const vector<vector<double>> &m, int p) : SlarMatica(m) //konstruktor nastavi pocet iteracii a vstupnu maticu
{
	pocetIteracii = p;
	NastavMaticu();

}


GaussSiedelMetoda::~GaussSiedelMetoda() //destruktor
{
}


bool GaussSiedelMetoda::Pocitaj()
{
	if (!chyba_matice)
	{
		int i = 0, j = 0;

		vector<double>  m;
		m.resize(rozmer);

		for (int i=0; i < rozmer; i++)
			m[i] = -100; //pociatocna hodnota, moze byt aj ina, nastavili sme nahodnu hodnotu

		ULONGLONG mtime = GetTickCount64();

		while (pocetIteracii> 0) { //hlavny iteracny cyklus
			for (i = 0; i < rozmer; i++) {
				vysledok[i] = (matica[i][rozmer] / matica[i][i]); //pravu stranu matice podelime prvkom na diagonale
				for (j = 0; j < rozmer; j++) {
					if (j != i) { //prechadzame vsetky stlpce okrem prvkov na diagonale
						vysledok[i] = vysledok[i] - ((matica[i][j] / matica[i][i]) * m[j]); //odratame prvok v j-tom stlpci podeleny prvkom na diagonale a vynasobeny predchadzajucim vysledkom
						m[i] = vysledok[i]; //odpamatame si vysledok pre dalsie pouzitie
					}
				}
			}
			pocetIteracii--; //skoncila jedna iteracia
		}

		cout << "\nCas vypoctu Gausso-Siedel metody: " << GetTickCount64() - mtime << " milisekund"; //vypocita cas

		cout << "\nVysledy:\n";
		for (i = 0; i < rozmer; i++) {
			cout << "x" << i + 1 << "=" << vysledok[i] << "\n"; //vypis na obrazovku
		}

		const char filename[] = "..\\data\\GSM.txt";
		ZapisVysledky((char*)filename);

		return true;
	}
	else
		return false;
}