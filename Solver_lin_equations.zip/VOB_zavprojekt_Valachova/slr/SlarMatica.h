#pragma once

#include <vector>

using namespace std;

class SlarMatica
{
protected:
	vector<vector<double>> matica;
	vector<double> vysledok;
	int rozmer;

	bool chyba_matice;

public:

	SlarMatica(const vector<vector<double>> &m);
	~SlarMatica();

	bool NastavMaticu();
	bool ZapisVysledky(char* filename);
	void PorovnajVysledky(const vector<double> &v);

	virtual bool Pocitaj();

};

